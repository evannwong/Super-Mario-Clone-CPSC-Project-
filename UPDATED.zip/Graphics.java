import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.Node;
import javafx.scene.image.ImageView;


public class Graphics{
  ImageView player = new ImageView("http://files.softicons.com/download/game-icons/super-mario-icons-by-sandro-pereira/png/256/Retro%20Mario.png");

  public Node createEntity(int x, int y, int w, int h, Color color){
    Rectangle entity = new Rectangle(w, h);
    entity.setTranslateX(x);
    entity.setTranslateY(y);
    entity.setFill(color);
    return entity;
  }

  public Node createCoin(int x, int y, int w, int h){
    ImageView coin = new ImageView("https://raw.githubusercontent.com/RMcCurdy/TeamProjectGroup14/master/Images/Coins/Coin1.png?token=ApkDjG3QpMdkdKtqJ4uwSCDIybeWTQbJks5cjg1RwA%3D%3D");
    coin.setX(x);
    coin.setY(y);
    coin.setFitWidth(w);
    coin.setFitHeight(h);
    return coin;
  }

  public Node createGoomba(int x, int y, int w, int h){
    ImageView goomba = new ImageView("https://static.giantbomb.com/uploads/original/9/93854/2438851-goomba+smb+sprite+walk+gif.gif");
    goomba.setX(x);
    goomba.setY(y);
    goomba.setFitWidth(w);
    goomba.setFitHeight(h);
    return goomba;
  }
}
